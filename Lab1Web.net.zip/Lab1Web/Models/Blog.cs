﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Lab1Web.Models
{
    public class Blog
    {
        [MaxLength(100)]
        public string Title { get; set; }
        [MaxLength(5000)]
        public string Content { get; set; }
        public Author Author { get; set; }
        public DateTime Date { get; set; }
    }
}
