﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Lab1Web.Pages.Admin.Blog
{
    public class CreateBlogModel : PageModel
    {
        [FromForm]
        public Models.Blog Blog { get; set; }
        private List<Models.Author> Authors { get; set; } = new List<Models.Author>();
        public IEnumerable<SelectListItem> AuthorList { get; private set; }

        public CreateBlogModel()
        {
            Models.Author a = new Models.Author()
            {
                Name = "Richard",
                Last = "Brown",
                Email = "richbro@lotsofbooks.com"
            };
            Models.Author b = new Models.Author()
            {
                Name = "Polly",
                Last = "Town",
                Email = "polto@ireadbooks.com"
            };
            Models.Author c = new Models.Author()
            {
                Name = "Jimmy",
                Last = "John",
                Email = "jimjo@writingbooks.com"
            };
            Authors.Add(a);
            Authors.Add(b);
            Authors.Add(c);
        }

        public void OnGet()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            foreach(var author in Authors)
            {
                list.Add(new SelectListItem(author.Name, author.Last));
            }
            AuthorList = list;
        }

        public void OnPost()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            foreach (var author in Authors)
            {
                list.Add(new SelectListItem(author.Name, author.Last));
                if(author.Last.Equals(Request.Form.ToList()[3].Value))
                {
                    Blog.Author = author;
                }
            }
            AuthorList = list;
        }

    }
}
